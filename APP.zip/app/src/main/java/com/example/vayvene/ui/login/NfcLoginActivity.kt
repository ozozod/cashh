package com.example.vayvene.ui.login

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.vayvene.R
import com.example.vayvene.data.Repository
import com.example.vayvene.data.Session
import com.example.vayvene.ui.admin.AdminMenuActivity
import com.example.vayvene.ui.main.SellerMenuActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale

class NfcLoginActivity : AppCompatActivity() {

    private var nfcAdapter: NfcAdapter? = null
    private lateinit var lblTitle: TextView
    private lateinit var lblSubtitle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nfc_login)

        lblTitle = findViewById(R.id.title)
        lblSubtitle = findViewById(R.id.subtitle)

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        if (nfcAdapter == null || !nfcAdapter!!.isEnabled) {
            Toast.makeText(this, "NFC deshabilitado en el dispositivo", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        // Si venimos por intent de reintento, limpiá cualquier mensaje
        lblSubtitle.text = getString(R.string.nfc_login_subtitle)
    }

    override fun onResume() {
        super.onResume()
        enableDispatch()
        // Si la activity fue lanzada por un tag ya presente
        intent?.let { handleIntent(it) }
    }

    override fun onPause() {
        super.onPause()
        disableDispatch()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        if (NfcAdapter.ACTION_TAG_DISCOVERED == intent.action ||
            NfcAdapter.ACTION_TECH_DISCOVERED == intent.action ||
            NfcAdapter.ACTION_NDEF_DISCOVERED == intent.action
        ) {
            val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
            if (tag != null) {
                val uid = tag.id?.toHexReversed().orEmpty()
                if (uid.isBlank()) {
                    Toast.makeText(this, "No pude leer la tarjeta", Toast.LENGTH_SHORT).show()
                    return
                }
                doLogin(uid)
            }
        }
    }

    private fun doLogin(cardUidReversed: String) {
        // UI feedback
        lblSubtitle.text = "Leyendo tarjeta…"

        lifecycleScope.launch {
            try {
                val ctx = this@NfcLoginActivity

                // ⬇️ AJUSTÁ ESTA LÍNEA si tu Repository usa otro nombre/parámetros
                val response: JSONObject = withContext(Dispatchers.IO) {
                    Repository.mobileLogin(ctx, cardUidReversed)
                }

                // Espero algo tipo: { token, eventId, isStaff, staffRole, userName }
                val token = response.optString("token")
                val eventId = response.optString("eventId")
                val isStaff = response.optBoolean("isStaff", false)
                val staffRole = response.optString("staffRole", "").uppercase(Locale.ROOT)

                if (token.isBlank() || eventId.isBlank()) {
                    throw IllegalStateException("Respuesta inválida del servidor")
                }

                // Guardar sesión (si tus helpers tienen otra firma, cambiá acá)
                Session.saveToken(ctx, token)
                Session.saveEventId(ctx, eventId)
                Session.saveIsStaff(ctx, isStaff)
                Session.saveStaffRole(ctx, staffRole)

                // Ruteo: SOLO ADMIN entra a AdminMenu. Encargado y vendedor van a Seller.
                routeAfterLogin(ctx, staffRole)

            } catch (e: Repository.HttpError) {
                // Error HTTP desde Repository (401, 409, etc)
                Toast.makeText(
                    this@NfcLoginActivity,
                    "Error de login: ${e.code} ${e.message ?: ""}",
                    Toast.LENGTH_LONG
                ).show()
                finish() // volvemos a la pantalla anterior (no se cuelga)
            } catch (e: Exception) {
                Toast.makeText(
                    this@NfcLoginActivity,
                    "Error de login. Volvé a intentar.",
                    Toast.LENGTH_LONG
                ).show()
                finish()
            }
        }
    }

    /**
     * Si es ADMINISTRADOR => AdminMenuActivity
     * Caso contrario => SellerMenuActivity
     */
    private fun routeAfterLogin(context: Context, staffRole: String?) {
        val goAdmin = staffRole.equals("ADMINISTRADOR", ignoreCase = true)

        val next = if (goAdmin) {
            Intent(context, AdminMenuActivity::class.java)
        } else {
            Intent(context, SellerMenuActivity::class.java)
        }

        next.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(next)
    }

    // NFC helpers
    private fun enableDispatch() {
        val intent = Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pending = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        nfcAdapter?.enableForegroundDispatch(this, pending, null, null)
    }

    private fun disableDispatch() {
        nfcAdapter?.disableForegroundDispatch(this)
    }

    private fun ByteArray.toHexReversed(): String {
        // UID leída normalmente llega little-endian => la damos vuelta por pares
        val hex = joinToString("") { "%02X".format(it) }
        return hex.chunked(2).reversed().joinToString("")
    }
}
