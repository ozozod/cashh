package com.example.vayvene.ui.seller

import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.vayvene.R
import com.example.vayvene.data.Repository
import com.example.vayvene.data.Session
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale

class SellerCancelLastSaleActivity : AppCompatActivity() {

    private lateinit var tvInfo: TextView
    private lateinit var btnAuth: Button
    private lateinit var btnCancel: Button

    private var lastSaleId: String? = null
    private var lastSaleHuman: String = ""

    private var nfcAdapter: NfcAdapter? = null
    private var awaiting: Awaiting = Awaiting.NONE

    private enum class Awaiting { NONE, AUTH_STAFF, CLIENT_CARD }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_seller_cancel_last_sale)

        tvInfo = findViewById(R.id.tvInfo)
        btnAuth = findViewById(R.id.btnAuthorize)
        btnCancel = findViewById(R.id.btnScanAndCancel)

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)

        // Cargar última venta
        loadLastSale()

        // Si el logueado es ADMIN o ENCARGADO, no pedimos tarjeta de staff
        val role = Session.getStaffRole(this).uppercase(Locale.ROOT)
        val isPrivileged = role == "ADMINISTRADOR" || role == "ENCARGADO"

        btnAuth.isEnabled = !isPrivileged
        btnAuth.alpha = if (isPrivileged) 0.4f else 1f

        btnAuth.setOnClickListener {
            if (isPrivileged) return@setOnClickListener
            awaiting = Awaiting.AUTH_STAFF
            Toast.makeText(this, "Acerque tarjeta de encargado/admin…", Toast.LENGTH_SHORT).show()
            enableDispatch()
        }

        btnCancel.setOnClickListener {
            // Si era privilegiado, directamente pedimos cliente.
            awaiting = Awaiting.CLIENT_CARD
            Toast.makeText(this, "Acerque tarjeta del cliente…", Toast.LENGTH_SHORT).show()
            enableDispatch()
        }
    }

    override fun onResume() {
        super.onResume()
        // No habilito dispatch permanente: lo habilito al apretar botones.
    }

    override fun onPause() {
        super.onPause()
        disableDispatch()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (awaiting == Awaiting.NONE) return

        if (NfcAdapter.ACTION_TAG_DISCOVERED == intent.action ||
            NfcAdapter.ACTION_TECH_DISCOVERED == intent.action ||
            NfcAdapter.ACTION_NDEF_DISCOVERED == intent.action
        ) {
            val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
            val uid = tag?.id?.toHexReversed().orEmpty()
            if (uid.isBlank()) {
                Toast.makeText(this, "No pude leer tarjeta", Toast.LENGTH_SHORT).show()
                return
            }

            when (awaiting) {
                Awaiting.AUTH_STAFF -> {
                    // Validar staff (opcional en backend). Si ok, habilitamos botón de cancelar.
                    awaiting = Awaiting.NONE
                    disableDispatch()
                    Toast.makeText(this, "Autorización concedida", Toast.LENGTH_SHORT).show()
                    btnCancel.isEnabled = true
                    btnCancel.alpha = 1f
                }

                Awaiting.CLIENT_CARD -> {
                    awaiting = Awaiting.NONE
                    disableDispatch()
                    doCancel(uid)
                }

                else -> Unit
            }
        }
    }

    private fun loadLastSale() {
        lifecycleScope.launch {
            try {
                val json: JSONObject = withContext(Dispatchers.IO) {
                    Repository.getLastSale(this@SellerCancelLastSaleActivity)
                }
                lastSaleId = json.optString("saleId")
                val total = json.optLong("total", 0L)
                val details = json.optString("detailsHuman", "")
                val client = json.optString("cardUid", "")

                lastSaleHuman = "Total: $ $total\nCliente: $client\nDetalles: $details"
                tvInfo.text = "Última venta\n$lastSaleHuman"

            } catch (e: Exception) {
                tvInfo.text = "No pude obtener la última venta"
                btnAuth.isEnabled = false
                btnCancel.isEnabled = false
            }
        }
    }

    private fun doCancel(clientUidReversed: String) {
        val saleId = lastSaleId ?: run {
            Toast.makeText(this, "No hay venta para anular", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    Repository.cancelLastSale(
                        context = this@SellerCancelLastSaleActivity,
                        saleId = saleId,
                        clientUid = clientUidReversed
                    )
                }
                Toast.makeText(this@SellerCancelLastSaleActivity, "Venta anulada ✔️", Toast.LENGTH_LONG).show()
                finish()

            } catch (e: Repository.HttpError) {
                Toast.makeText(
                    this@SellerCancelLastSaleActivity,
                    "Error ${e.code}: ${e.message ?: "No se pudo anular"}",
                    Toast.LENGTH_LONG
                ).show()
            } catch (e: Exception) {
                Toast.makeText(
                    this@SellerCancelLastSaleActivity,
                    "No se pudo anular. Intentá de nuevo.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun enableDispatch() {
        val intent = Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pending = android.app.PendingIntent.getActivity(
            this, 0, intent,
            android.app.PendingIntent.FLAG_MUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        nfcAdapter?.enableForegroundDispatch(this, pending, null, null)
    }

    private fun disableDispatch() {
        nfcAdapter?.disableForegroundDispatch(this)
    }

    private fun ByteArray.toHexReversed(): String {
        val hex = joinToString("") { "%02X".format(it) }
        return hex.chunked(2).reversed().joinToString("")
    }
}
